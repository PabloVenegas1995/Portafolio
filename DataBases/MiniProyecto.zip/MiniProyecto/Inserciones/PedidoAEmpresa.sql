
INSERT INTO "pedidoaempresa" (RUTCliente,fecha,NumeroPedido,cantidad,MaterialPedido,IDPedidoEmpresa) VALUES 
('11.111.111-1','2016/08/01','1','10','pavimento de gres','147'),
('11.111.111-1','2016/10/20','2','10','pavimento de gres','258'),
('44.444.444-4','2016/10/20','1','10','pavimento de gres','369'),
('44.444.444-4','2016/10/20','2','10','acero','741'),
('55.555.555-5','2016/08/02','1','10','pavimento de gres','852');

