INSERT INTO "cliente" (RUT,Nombre,Direccion,CodigoPostal) VALUES 
('11.111.111-1','Danny Rand','Hells Kitchen','1111'),
('22.222.222-2','Matt Murdock','Hells Kitchen','2222'),
('33.333.333-3','John Smith','Hells Kitchen','3333'),
('44.444.444-4','Jessica Jones','Hells Kitchen','4444'),
('55.555.555-5','Luke Cage','Hells Kitchen','5555');